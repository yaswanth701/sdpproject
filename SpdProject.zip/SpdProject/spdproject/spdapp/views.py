from django.contrib.auth.decorators import login_required
from  django.db.models import Q
from django.http import HttpResponse
from django.shortcuts import render

# Create your views here.
from django.shortcuts import render,redirect

from .forms import RegistrationForm, ProductForm
from .models import Registration, Admin, Product


def indexfunction(request):
    return render(request,"index.html")
def registration(request):
    form = RegistrationForm()

    if request.method == "POST":
        form=RegistrationForm(request.POST)
        if form.is_valid():
            form.save()
            msg = "Successfully Registered"
            return render(request,"regsuccess.html",{"msg":msg})
        else:
            return HttpResponse("Registration Failed")

    return render(request,"registration.html",{"form":form})
def userlogin(request):
    return render(request,"userlogin.html")
def viewprodectsinad(request):
    return render(request,"viewprodectsinad.html")

def checkuserlogin(request):
    emailid=request.POST["emailid"]
    pwd=request.POST["password"]

    flag=Registration.objects.filter( Q(email=emailid) & Q(password=pwd) )

    if flag:
        return render(request,"userhome.html")
    else:
        msg="Login Failed"
        return render(request, "userlogin.html",{"msg":msg})

def userhome(request):
    return render(request,"userhome.html")

def userlogout(request):
    return render(request,"userlogin.html")
def newproject(request):
    return render(request,"newproducts.html")
def sparepart(request):
    return render(request,"spateparts.html")
def addproduct(request):
    auname = request.session["auname"]
    form = ProductForm()
    if request.method == "POST":
        formdata = ProductForm(request.POST,request.FILES)
        if formdata.is_valid():
            formdata.save()
            msg="Product Added Successfully"
            return render(request, "addproduct.html", {"auname":auname,"productform": form,"msg":msg})
        else:
            msg = "Failed to Add Product"
            return render(request, "addproduct.html", {"auname":auname,"productform": form, "msg": msg})
    return render(request,"addproduct.html",{"auname":auname,"productform":form})
@login_required
def empchangepwd(request):
    pid=request.session["pid"]
    any=request.session["name"]
    return render(request,"empchangepwd.html",{"pid":pid,"name":any})

def empupdatepwd(request):
    r_id=request.session["r_id"]
    r_username=request.session["r_username"]
    opwd=request.POST["opwd"]
    npwd=request.POST["npwd"]

    flag = registration().objects.filter(Q(id=r_id) & Q(password=opwd))

    if flag:
        registration().objects.filter(id=r_id).update(password=npwd)
        msg = "Password Updated Successfully"
        return render(request, "empchangepwd.html", {"eid": r_id, "ename": r_username,"msg":msg})
    else:
        msg = "Old Password is Incorrect"
        return render(request, "empchangepwd.html", {"eid": r_id, "ename": r_username,"msg":msg})

def adminhome(request):
    auname=request.session["auname"]
    return render(request,"adminhome.html")

def viewaproducts(request):
    auname=request.session["auname"]
    productlist = Product.objects.all()
    count = Product.objects.count()
    return render(request,"viewaproducts.html",{"auname":auname,"productlist":productlist,"count":count})

def adminlogin(request):
    return render(request,"adminlogin.html")

def checkadminlogin(request):
    uname = request.POST["ausername"]
    pwd = request.POST["apassword"]

    flag = Admin.objects.filter(Q(username__exact=uname) & Q(password__exact=pwd))
    print(flag)

    if flag:
        admin = Admin.objects.get(username=uname)
        print(admin)
        request.session["auname"] = admin.username
        return render(request, "adminhome.html", {"auname": admin.username})
    else:
        msg = "Login Failed"
        return render(request, "adminlogin.html", {"msg": msg})

def adminlogout(request):
    return render(request,"adminlogin.html")

def displayeproducts(request):

    eid=request.session["eid"]
    ename=request.session["ename"]

    pname = request.POST["pname"]
    print(pname)

    productlist = Product.objects.filter(name__icontains=pname)

    return render(request,"displayeproducts.html",{"eid": eid, "ename": ename,"productlist":productlist})
